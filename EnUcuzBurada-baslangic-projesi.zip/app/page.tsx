const products = [
  { name: "Kablosuz Kulaklık", price: "₺499,90", category: "Elektronik", tag: "Çok satan" },
  { name: "Günlük Sırt Çantası", price: "₺349,90", category: "Moda", tag: "Yeni" },
  { name: "Paslanmaz Çelik Termos", price: "₺229,90", category: "Ev & Yaşam", tag: "Fırsat" },
  { name: "Masa Lambası", price: "₺279,90", category: "Ev & Yaşam", tag: "Popüler" }
];

export default function Home() {
  return <main>
    <header className="top"><a className="brand" href="/">EnUcuzBurada</a><nav><a href="#kategoriler">Kategoriler</a><a href="/customer">Hesabım</a><a href="/seller">Mağaza Aç</a></nav></header>
    <section className="hero"><p className="eyebrow">AKILLI ALIŞVERİŞİN ADRESİ</p><h1>Aradığın ürün,<br/><span>en ucuz burada.</span></h1><p>Farklı mağazaları keşfet, fırsatları yakala.</p><div className="search"><input aria-label="Ürün ara" placeholder="Hangi ürünü arıyorsun?"/><button>Ara</button></div></section>
    <section id="kategoriler" className="section"><div className="sectionHead"><div><p className="eyebrow">KEŞFET</p><h2>Popüler kategoriler</h2></div></div><div className="categories"><a>Elektronik</a><a>Moda</a><a>Ev & Yaşam</a><a>Kozmetik</a><a>Spor</a><a>Anne & Bebek</a></div></section>
    <section className="section"><div className="sectionHead"><div><p className="eyebrow">SENİN İÇİN SEÇTİK</p><h2>Öne çıkan ürünler</h2></div><span className="muted">Örnek ürünler</span></div><div className="products">{products.map((p, i)=><article className="product" key={p.name}><div className={"productArt art"+i}><span>{p.category}</span><b>{["🎧","🎒","☕","💡"][i]}</b></div><div className="productInfo"><small>{p.tag}</small><h3>{p.name}</h3><strong>{p.price}</strong><button>Sepete ekle</button></div></article>)}</div></section>
    <footer>© 2026 EnUcuzBurada · Komisyon modeli: %5</footer>
  </main>;
}
