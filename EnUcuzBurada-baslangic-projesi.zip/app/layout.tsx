import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EnUcuzBurada | Uygun Fiyatlı Alışveriş",
  description: "EnUcuzBurada çevrimiçi alışveriş pazaryeri"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="tr"><body>{children}</body></html>;
}
