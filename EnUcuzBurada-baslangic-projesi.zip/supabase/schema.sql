-- EnUcuzBurada başlangıç şeması (PostgreSQL / Supabase)
create extension if not exists pgcrypto;
create table if not exists profiles (
  id uuid primary key,
  email text unique,
  full_name text,
  role text not null default 'customer' check (role in ('customer','seller','admin')),
  created_at timestamptz not null default now()
);
create table if not exists stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id),
  name text not null,
  slug text unique not null,
  status text not null default 'active' check (status in ('pending','active','suspended')),
  created_at timestamptz not null default now()
);
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id),
  title text not null,
  description text,
  price numeric(12,2) not null check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  active boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references profiles(id),
  status text not null default 'created',
  total numeric(12,2) not null check (total >= 0),
  commission_rate numeric(5,4) not null default 0.05,
  created_at timestamptz not null default now()
);
alter table profiles enable row level security;
alter table stores enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
-- Güvenli RLS politikaları ve ödeme entegrasyonu canlıya çıkmadan önce ayrıca tanımlanmalıdır.
